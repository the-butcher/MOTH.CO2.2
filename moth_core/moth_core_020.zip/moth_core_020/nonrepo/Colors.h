#ifndef Colors_h
#define Colors_h

#include "ColorRgb.h"
#include "ColorHsv.h"
#include "Thresholds.h"

class Colors {
  
  private:
    
  public:
    static ColorRgb toRgb(int co2, Thresholds thresholdsCo2);
    static ColorRgb toRgb(ColorHsv hsv);
    static ColorHsv toHsv(ColorRgb rgb);

};

#endif