#ifndef ColorRgb_h
#define ColorRgb_h

typedef struct {
  float r;
  float g;
  float b;
} ColorRgb;

#endif