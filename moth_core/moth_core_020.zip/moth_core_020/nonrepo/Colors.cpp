#include "Colors.h"
#include <cmath>

ColorRgb Colors::toRgb(int co2, Thresholds thresholdsCo2) {
  if (co2 <= thresholdsCo2.warnHi) {
    return {
      0, 1, 0
    };
  } else if (co2 >= thresholdsCo2.riskHi) {
    return {
      1, 0, 0
    };
  } else {
    float fraction = (co2 - thresholdsCo2.warnHi) * 1.0 / (thresholdsCo2.riskHi - thresholdsCo2.warnHi);
    float h = 0.33 * (1 - fraction);
    return Colors::toRgb({
      h, 1, 1
    });
  }

}

ColorRgb Colors::toRgb(ColorHsv hsv) {

  if (hsv.s == 0) {

      return {
        hsv.v,
        hsv.v,
        hsv.v
      };

  } else {

      float a = (hsv.h - floor(hsv.h)) * 6.0;
      float f = a - floor(a);
      float p = hsv.v * (1.0 - hsv.s);
      float q = hsv.v * (1.0 - hsv.s * f);
      float t = hsv.v * (1.0 - hsv.s * (1.0 - f));

      int floora = floor(a);
      switch (floora) {
        case 0:
          return {
            hsv.v, t, p
          };
        case 1:
          return {
            q, hsv.v, p
          };
        case 2:
          return {
            p, hsv.v, t
          };
        case 3:
          return {
            p, q, hsv.v
          };
        case 4:
          return {
            t, p, hsv.v
          };
        case 5:
          return {
            hsv.v, p, q
          };
      }

  }

  return {
    0.0, 0.0, 0.0
  };

}

ColorHsv Colors::toHsv(ColorRgb rgb) {

  float r_replace = rgb.r;
  float g_replace = rgb.g;
  float b_replace = rgb.b;

  float h;
  float s;
  float v;

  float cmax = r_replace > g_replace ? r_replace : g_replace;
  if (b_replace > cmax) {
      cmax = b_replace;
  }

  float cmin = r_replace < g_replace ? r_replace : g_replace;
  if (b_replace < cmin) {
      cmin = b_replace;
  }

  v = cmax;
  if (cmax != 0) {
      s = (cmax - cmin) * 1.0 / cmax;
  } else {
      s = 0.0;
  }

  if (s == 0) {
      h = 0;
  } else {

      float rc = (cmax - r_replace) * 1.0 / (cmax - cmin);
      float gc = (cmax - g_replace) * 1.0 / (cmax - cmin);
      float bc = (cmax - b_replace) * 1.0 / (cmax - cmin);

      if (r_replace == cmax) {
          h = bc - gc;
      } else if (g_replace == cmax) {
          h = 2.0 + rc - bc;
      } else {
          h = 4.0 + gc - rc;
      }

      h = h / 6.0;
      if (h < 0) {
          h = h + 1.0;
      }

  }

  return {
    h, s, v
  };

}
