#ifndef ColorHsv_h
#define ColorHsv_h

typedef struct {
  float h;
  float s;
  float v;
} ColorHsv;

#endif