#ifndef ValuesBat_h
#define ValuesBat_h

typedef struct {
  float percent;
  float voltage;
  bool  powered;
} ValuesBat;

#endif