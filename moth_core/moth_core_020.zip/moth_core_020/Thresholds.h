#ifndef Thresholds_h
#define Thresholds_h

typedef struct {
  int riskLo;
  int warnLo;
  int warnHi;
  int riskHi;
} Thresholds;

#endif