#ifndef Rectangle_h
#define Rectangle_h

typedef struct {
  int xmin;
  int ymin;
  int xmax;
  int ymax;
} Rectangle;

#endif