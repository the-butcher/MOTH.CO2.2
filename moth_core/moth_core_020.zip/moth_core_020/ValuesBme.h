#ifndef ValuesBme_h
#define ValuesBme_h

typedef struct {
  float temperature;
  float humidity;
  float pressure;
} ValuesBme;

#endif