#ifndef DataFileDef_h
#define DataFileDef_h

typedef struct {
  String path;
  String name;
} DataFileDef;

#endif